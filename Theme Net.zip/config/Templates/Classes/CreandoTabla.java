<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

<#if package?? && package != "">
package ${package};

</#if>
/**
 *
 * @author Jeison Perez
 * @email jeisonj_2008@hotmail.com
 * @Company Sin Crear una aun.
 */
public class ${name} {

    DefaultTableModel modeloTabla;
    String [][] datos = {};
    String [] column = {};

    public void CreandoTabla(){
    
        modeloTabla = new DefaultTableModel(datos,column);
        tabla.setModel(modeloTabla);
    }
}
